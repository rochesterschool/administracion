
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VProfesorAsignatura
 *  12/07/2011 16:52:37
 * 
 */
public class VProfesorAsignatura {

    private VProfesorAsignaturaId id;

    public VProfesorAsignatura() {
    }

    public VProfesorAsignatura(VProfesorAsignaturaId id) {
        this.id = id;
    }

    public VProfesorAsignaturaId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaId id) {
        this.id = id;
    }

}
