
package com.aprendoz_desarrollo;



/**
 *  Query names for service "aprendoz_desarrollo"
 *  12/07/2011 16:53:08
 * 
 */
public class Aprendoz_desarrolloConstants {

    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";

    private Aprendoz_desarrolloConstants() {
        throw new UnsupportedOperationException();
    }

}
