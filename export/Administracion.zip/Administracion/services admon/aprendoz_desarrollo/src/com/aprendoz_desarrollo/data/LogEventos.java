
package com.aprendoz_desarrollo.data;

import java.util.Date;


/**
 *  aprendoz_desarrollo.LogEventos
 *  12/07/2011 16:52:37
 * 
 */
public class LogEventos {

    private Integer idLog;
    private String evento;
    private String origenEvento;
    private String dato1;
    private String dato2;
    private String dato3;
    private String dato4;
    private String dato5;
    private String dato6;
    private String dato7;
    private String dato8;
    private String dato9;
    private String dato10;
    private Date fechaDelRegistro;
    private Integer tipoPersonaSoloPersona;
    private Date fechaEvento;

    public LogEventos() {
    }

    public LogEventos(Integer idLog, String evento, String origenEvento, String dato1, String dato2, String dato3, String dato4, String dato5, String dato6, String dato7, String dato8, String dato9, String dato10, Date fechaDelRegistro, Integer tipoPersonaSoloPersona, Date fechaEvento) {
        this.idLog = idLog;
        this.evento = evento;
        this.origenEvento = origenEvento;
        this.dato1 = dato1;
        this.dato2 = dato2;
        this.dato3 = dato3;
        this.dato4 = dato4;
        this.dato5 = dato5;
        this.dato6 = dato6;
        this.dato7 = dato7;
        this.dato8 = dato8;
        this.dato9 = dato9;
        this.dato10 = dato10;
        this.fechaDelRegistro = fechaDelRegistro;
        this.tipoPersonaSoloPersona = tipoPersonaSoloPersona;
        this.fechaEvento = fechaEvento;
    }

    public Integer getIdLog() {
        return idLog;
    }

    public void setIdLog(Integer idLog) {
        this.idLog = idLog;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getOrigenEvento() {
        return origenEvento;
    }

    public void setOrigenEvento(String origenEvento) {
        this.origenEvento = origenEvento;
    }

    public String getDato1() {
        return dato1;
    }

    public void setDato1(String dato1) {
        this.dato1 = dato1;
    }

    public String getDato2() {
        return dato2;
    }

    public void setDato2(String dato2) {
        this.dato2 = dato2;
    }

    public String getDato3() {
        return dato3;
    }

    public void setDato3(String dato3) {
        this.dato3 = dato3;
    }

    public String getDato4() {
        return dato4;
    }

    public void setDato4(String dato4) {
        this.dato4 = dato4;
    }

    public String getDato5() {
        return dato5;
    }

    public void setDato5(String dato5) {
        this.dato5 = dato5;
    }

    public String getDato6() {
        return dato6;
    }

    public void setDato6(String dato6) {
        this.dato6 = dato6;
    }

    public String getDato7() {
        return dato7;
    }

    public void setDato7(String dato7) {
        this.dato7 = dato7;
    }

    public String getDato8() {
        return dato8;
    }

    public void setDato8(String dato8) {
        this.dato8 = dato8;
    }

    public String getDato9() {
        return dato9;
    }

    public void setDato9(String dato9) {
        this.dato9 = dato9;
    }

    public String getDato10() {
        return dato10;
    }

    public void setDato10(String dato10) {
        this.dato10 = dato10;
    }

    public Date getFechaDelRegistro() {
        return fechaDelRegistro;
    }

    public void setFechaDelRegistro(Date fechaDelRegistro) {
        this.fechaDelRegistro = fechaDelRegistro;
    }

    public Integer getTipoPersonaSoloPersona() {
        return tipoPersonaSoloPersona;
    }

    public void setTipoPersonaSoloPersona(Integer tipoPersonaSoloPersona) {
        this.tipoPersonaSoloPersona = tipoPersonaSoloPersona;
    }

    public Date getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(Date fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

}
