
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Anuncio
 *  12/07/2011 16:52:37
 * 
 */
public class Anuncio {

    private String anuncio;

    public Anuncio() {
    }

    public Anuncio(String anuncio) {
        this.anuncio = anuncio;
    }

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
