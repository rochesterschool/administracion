
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEst
 *  12/07/2011 16:52:37
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEst() {
    }

    public CalifEst(CalifEstId id) {
        this.id = id;
    }

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
