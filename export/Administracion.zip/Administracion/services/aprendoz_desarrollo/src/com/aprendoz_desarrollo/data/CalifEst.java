
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEst
 *  08/23/2011 14:29:37
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEst() {
    }

    public CalifEst(CalifEstId id) {
        this.id = id;
    }

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
