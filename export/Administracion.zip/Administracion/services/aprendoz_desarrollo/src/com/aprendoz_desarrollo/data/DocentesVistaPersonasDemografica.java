
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaPersonasDemografica
 *  09/28/2012 12:19:45
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemografica() {
    }

    public DocentesVistaPersonasDemografica(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
