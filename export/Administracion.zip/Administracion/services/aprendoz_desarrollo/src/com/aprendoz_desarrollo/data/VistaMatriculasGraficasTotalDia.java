
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaMatriculasGraficasTotalDia
 *  09/28/2012 12:19:45
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDia() {
    }

    public VistaMatriculasGraficasTotalDia(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}
