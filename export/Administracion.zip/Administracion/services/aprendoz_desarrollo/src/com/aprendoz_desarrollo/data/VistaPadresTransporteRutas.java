
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPadresTransporteRutas
 *  09/28/2012 12:19:45
 * 
 */
public class VistaPadresTransporteRutas {

    private VistaPadresTransporteRutasId id;

    public VistaPadresTransporteRutas() {
    }

    public VistaPadresTransporteRutas(VistaPadresTransporteRutasId id) {
        this.id = id;
    }

    public VistaPadresTransporteRutasId getId() {
        return id;
    }

    public void setId(VistaPadresTransporteRutasId id) {
        this.id = id;
    }

}
