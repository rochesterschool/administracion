
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Ee
 *  12/28/2011 12:36:26
 * 
 */
public class Ee {

    private EeId id;

    public Ee() {
    }

    public Ee(EeId id) {
        this.id = id;
    }

    public EeId getId() {
        return id;
    }

    public void setId(EeId id) {
        this.id = id;
    }

}
