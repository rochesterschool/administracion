
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPadresRutasAlumnos
 *  09/28/2012 12:19:45
 * 
 */
public class VistaPadresRutasAlumnos {

    private VistaPadresRutasAlumnosId id;

    public VistaPadresRutasAlumnos() {
    }

    public VistaPadresRutasAlumnos(VistaPadresRutasAlumnosId id) {
        this.id = id;
    }

    public VistaPadresRutasAlumnosId getId() {
        return id;
    }

    public void setId(VistaPadresRutasAlumnosId id) {
        this.id = id;
    }

}
