
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaInscAlumnAsig
 *  09/28/2012 12:19:45
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsig() {
    }

    public DocentesVistaInscAlumnAsig(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
