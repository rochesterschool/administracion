
package com.aprendoz_desarrollo.data;

import java.util.Date;


/**
 *  aprendoz_desarrollo.LogDocentes
 *  09/28/2012 12:19:45
 * 
 */
public class LogDocentes {

    private Integer idLogDocentes;
    private Integer personaIdPersona;
    private Date fechaIngreso;
    private Date horaIngreso;

    public LogDocentes() {
    }

    public LogDocentes(Integer idLogDocentes, Integer personaIdPersona, Date fechaIngreso, Date horaIngreso) {
        this.idLogDocentes = idLogDocentes;
        this.personaIdPersona = personaIdPersona;
        this.fechaIngreso = fechaIngreso;
        this.horaIngreso = horaIngreso;
    }

    public Integer getIdLogDocentes() {
        return idLogDocentes;
    }

    public void setIdLogDocentes(Integer idLogDocentes) {
        this.idLogDocentes = idLogDocentes;
    }

    public Integer getPersonaIdPersona() {
        return personaIdPersona;
    }

    public void setPersonaIdPersona(Integer personaIdPersona) {
        this.personaIdPersona = personaIdPersona;
    }

    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Date getHoraIngreso() {
        return horaIngreso;
    }

    public void setHoraIngreso(Date horaIngreso) {
        this.horaIngreso = horaIngreso;
    }

}
