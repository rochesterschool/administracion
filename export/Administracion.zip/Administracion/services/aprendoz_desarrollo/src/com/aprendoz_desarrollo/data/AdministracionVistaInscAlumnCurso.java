
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaInscAlumnCurso
 *  09/28/2012 12:19:45
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCurso() {
    }

    public AdministracionVistaInscAlumnCurso(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
