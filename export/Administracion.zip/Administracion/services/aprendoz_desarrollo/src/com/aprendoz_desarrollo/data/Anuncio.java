
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Anuncio
 *  08/23/2011 14:29:37
 * 
 */
public class Anuncio {

    private String anuncio;

    public Anuncio() {
    }

    public Anuncio(String anuncio) {
        this.anuncio = anuncio;
    }

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
