
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaInscAlumnCurso
 *  09/28/2012 12:19:45
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCurso() {
    }

    public VistaInscAlumnCurso(VistaInscAlumnCursoId id) {
        this.id = id;
    }

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
