
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VProfesorAsignaturaCompleto
 *  09/28/2012 12:19:45
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompleto() {
    }

    public VProfesorAsignaturaCompleto(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}
