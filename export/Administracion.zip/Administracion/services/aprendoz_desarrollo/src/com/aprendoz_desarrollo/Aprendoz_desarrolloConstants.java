
package com.aprendoz_desarrollo;



/**
 *  Query names for service "aprendoz_desarrollo"
 *  08/23/2011 14:30:28
 * 
 */
public class Aprendoz_desarrolloConstants {

    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";

    private Aprendoz_desarrolloConstants() {
        throw new UnsupportedOperationException();
    }

}
