
package com.aprendoz_desarrollo;



/**
 *  Query names for service "aprendoz_desarrollo"
 *  04/12/2013 10:06:19
 * 
 */
public class Aprendoz_desarrolloConstants {

    public final static String HQLlsCursosQueryName = "HQLlsCursos";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";
    public final static String getProcesoMatriculaQueryName = "getProcesoMatricula";
    public final static String getNombreCompletoQueryName = "getNombreCompleto";

    private Aprendoz_desarrolloConstants() {
        throw new UnsupportedOperationException();
    }

}
