
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscipcionesVistaAsignaturas
 *  09/28/2012 12:19:45
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturas() {
    }

    public InscipcionesVistaAsignaturas(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
