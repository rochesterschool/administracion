
package com.aprendoz_desarrollo.data;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;


/**
 *  aprendoz_desarrollo.Eventualidades
 *  09/28/2012 12:19:45
 * 
 */
public class Eventualidades {

    private Integer idEventualidad;
    private TipoLugar tipoLugar;
    private SubtipoEventualidad subtipoEventualidad;
    private Date fecha;
    private Date hora;
    private String estado;
    private String descripcion;
    private Date fechaIngreso;
    private String usuarioReg;
    private Set<com.aprendoz_desarrollo.data.EventualidadPersonas> eventualidadPersonases = new HashSet<com.aprendoz_desarrollo.data.EventualidadPersonas>();

    public Eventualidades() {
    }

    public Eventualidades(Integer idEventualidad, Date fecha, Date hora, String estado, String descripcion, Date fechaIngreso, String usuarioReg) {
        this.idEventualidad = idEventualidad;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
        this.descripcion = descripcion;
        this.fechaIngreso = fechaIngreso;
        this.usuarioReg = usuarioReg;
    }

    public Eventualidades(Integer idEventualidad, TipoLugar tipoLugar, SubtipoEventualidad subtipoEventualidad, Date fecha, Date hora, String estado, String descripcion, Date fechaIngreso, String usuarioReg, Set<com.aprendoz_desarrollo.data.EventualidadPersonas> eventualidadPersonases) {
        this.idEventualidad = idEventualidad;
        this.tipoLugar = tipoLugar;
        this.subtipoEventualidad = subtipoEventualidad;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
        this.descripcion = descripcion;
        this.fechaIngreso = fechaIngreso;
        this.usuarioReg = usuarioReg;
        this.eventualidadPersonases = eventualidadPersonases;
    }

    public Integer getIdEventualidad() {
        return idEventualidad;
    }

    public void setIdEventualidad(Integer idEventualidad) {
        this.idEventualidad = idEventualidad;
    }

    public TipoLugar getTipoLugar() {
        return tipoLugar;
    }

    public void setTipoLugar(TipoLugar tipoLugar) {
        this.tipoLugar = tipoLugar;
    }

    public SubtipoEventualidad getSubtipoEventualidad() {
        return subtipoEventualidad;
    }

    public void setSubtipoEventualidad(SubtipoEventualidad subtipoEventualidad) {
        this.subtipoEventualidad = subtipoEventualidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getUsuarioReg() {
        return usuarioReg;
    }

    public void setUsuarioReg(String usuarioReg) {
        this.usuarioReg = usuarioReg;
    }

    public Set<com.aprendoz_desarrollo.data.EventualidadPersonas> getEventualidadPersonases() {
        return eventualidadPersonases;
    }

    public void setEventualidadPersonases(Set<com.aprendoz_desarrollo.data.EventualidadPersonas> eventualidadPersonases) {
        this.eventualidadPersonases = eventualidadPersonases;
    }

}
