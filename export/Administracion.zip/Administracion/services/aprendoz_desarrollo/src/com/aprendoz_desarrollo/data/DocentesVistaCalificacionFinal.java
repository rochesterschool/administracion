
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaCalificacionFinal
 *  09/28/2012 12:19:45
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinal() {
    }

    public DocentesVistaCalificacionFinal(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
