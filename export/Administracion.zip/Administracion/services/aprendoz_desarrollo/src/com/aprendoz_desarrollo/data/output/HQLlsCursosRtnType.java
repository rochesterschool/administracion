
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "HQLlsCursos" on 04/12/2013 10:06:13
 * 
 */
public class HQLlsCursosRtnType {

    private Integer id;
    private String curso;
    private Integer idgrado;

    public HQLlsCursosRtnType() {
    }

    public HQLlsCursosRtnType(Integer id, String curso, Integer idgrado) {
        this.id = id;
        this.curso = curso;
        this.idgrado = idgrado;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getIdgrado() {
        return idgrado;
    }

    public void setIdgrado(Integer idgrado) {
        this.idgrado = idgrado;
    }

}
