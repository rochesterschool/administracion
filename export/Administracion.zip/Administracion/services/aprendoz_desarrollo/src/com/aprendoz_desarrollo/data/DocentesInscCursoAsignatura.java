
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInscCursoAsignatura
 *  09/28/2012 12:19:45
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignatura() {
    }

    public DocentesInscCursoAsignatura(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
