
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaPersonas
 *  09/28/2012 12:19:44
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonas() {
    }

    public AdministracionVistaPersonas(AdministracionVistaPersonasId id) {
        this.id = id;
    }

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
