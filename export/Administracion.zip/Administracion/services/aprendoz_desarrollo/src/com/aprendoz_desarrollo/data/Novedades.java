
package com.aprendoz_desarrollo.data;

import java.util.Date;


/**
 *  aprendoz_desarrollo.Novedades
 *  09/28/2012 12:19:45
 * 
 */
public class Novedades {

    private Integer idNovedades;
    private Rutas rutas;
    private Persona persona;
    private TipoDia tipoDia;
    private Date horaProgramada;
    private String observaciones;
    private Date horaActualSalida;
    private Byte aprobacionDirNivel;
    private Byte aprobacionCoordinador;
    private Byte aprobacionTransporte;
    private Integer numeroPuerta;
    private Date fechaProgramada;
    private Date fechaSolicitud;

    public Novedades() {
    }

    public Novedades(Integer idNovedades, Date horaProgramada, String observaciones, Date horaActualSalida, Byte aprobacionDirNivel, Byte aprobacionCoordinador, Byte aprobacionTransporte, Integer numeroPuerta, Date fechaProgramada, Date fechaSolicitud) {
        this.idNovedades = idNovedades;
        this.horaProgramada = horaProgramada;
        this.observaciones = observaciones;
        this.horaActualSalida = horaActualSalida;
        this.aprobacionDirNivel = aprobacionDirNivel;
        this.aprobacionCoordinador = aprobacionCoordinador;
        this.aprobacionTransporte = aprobacionTransporte;
        this.numeroPuerta = numeroPuerta;
        this.fechaProgramada = fechaProgramada;
        this.fechaSolicitud = fechaSolicitud;
    }

    public Novedades(Integer idNovedades, Rutas rutas, Persona persona, TipoDia tipoDia, Date horaProgramada, String observaciones, Date horaActualSalida, Byte aprobacionDirNivel, Byte aprobacionCoordinador, Byte aprobacionTransporte, Integer numeroPuerta, Date fechaProgramada, Date fechaSolicitud) {
        this.idNovedades = idNovedades;
        this.rutas = rutas;
        this.persona = persona;
        this.tipoDia = tipoDia;
        this.horaProgramada = horaProgramada;
        this.observaciones = observaciones;
        this.horaActualSalida = horaActualSalida;
        this.aprobacionDirNivel = aprobacionDirNivel;
        this.aprobacionCoordinador = aprobacionCoordinador;
        this.aprobacionTransporte = aprobacionTransporte;
        this.numeroPuerta = numeroPuerta;
        this.fechaProgramada = fechaProgramada;
        this.fechaSolicitud = fechaSolicitud;
    }

    public Integer getIdNovedades() {
        return idNovedades;
    }

    public void setIdNovedades(Integer idNovedades) {
        this.idNovedades = idNovedades;
    }

    public Rutas getRutas() {
        return rutas;
    }

    public void setRutas(Rutas rutas) {
        this.rutas = rutas;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public TipoDia getTipoDia() {
        return tipoDia;
    }

    public void setTipoDia(TipoDia tipoDia) {
        this.tipoDia = tipoDia;
    }

    public Date getHoraProgramada() {
        return horaProgramada;
    }

    public void setHoraProgramada(Date horaProgramada) {
        this.horaProgramada = horaProgramada;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public Date getHoraActualSalida() {
        return horaActualSalida;
    }

    public void setHoraActualSalida(Date horaActualSalida) {
        this.horaActualSalida = horaActualSalida;
    }

    public Byte getAprobacionDirNivel() {
        return aprobacionDirNivel;
    }

    public void setAprobacionDirNivel(Byte aprobacionDirNivel) {
        this.aprobacionDirNivel = aprobacionDirNivel;
    }

    public Byte getAprobacionCoordinador() {
        return aprobacionCoordinador;
    }

    public void setAprobacionCoordinador(Byte aprobacionCoordinador) {
        this.aprobacionCoordinador = aprobacionCoordinador;
    }

    public Byte getAprobacionTransporte() {
        return aprobacionTransporte;
    }

    public void setAprobacionTransporte(Byte aprobacionTransporte) {
        this.aprobacionTransporte = aprobacionTransporte;
    }

    public Integer getNumeroPuerta() {
        return numeroPuerta;
    }

    public void setNumeroPuerta(Integer numeroPuerta) {
        this.numeroPuerta = numeroPuerta;
    }

    public Date getFechaProgramada() {
        return fechaProgramada;
    }

    public void setFechaProgramada(Date fechaProgramada) {
        this.fechaProgramada = fechaProgramada;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

}
