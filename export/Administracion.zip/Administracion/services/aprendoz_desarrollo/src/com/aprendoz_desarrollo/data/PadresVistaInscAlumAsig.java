
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInscAlumAsig
 *  09/28/2012 12:19:45
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsig() {
    }

    public PadresVistaInscAlumAsig(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
