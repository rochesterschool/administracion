
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaDristribucionAlumnosCursos
 *  09/28/2012 12:19:45
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursos() {
    }

    public DocentesVistaDristribucionAlumnosCursos(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
