
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPersonasGrupoFamiliar
 *  09/28/2012 12:19:45
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliar() {
    }

    public VistaPersonasGrupoFamiliar(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
